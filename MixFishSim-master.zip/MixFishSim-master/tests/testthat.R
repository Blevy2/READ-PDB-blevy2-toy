library(testthat)
library(MixFishSim)

test_check("MixFishSim")
